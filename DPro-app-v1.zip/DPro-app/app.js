'use strict';
// Demo-only state. DO NOT connect these controls directly to flight hardware.
const $ = (id) => document.getElementById(id);
const state = { mode: 'docked', battery: 100, altitude: 0, seconds: 0, alerts: true, log: [] };
const currentTime = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
let toastTimer;
function toast(message) { const el = $('toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3100); }
function addEvent(title, detail, symbol = '◇') {
  state.log.unshift({ title, detail, symbol, time: currentTime() });
  renderEvents();
}
function renderEvents() {
  for (const id of ['events-list', 'log-list']) {
    const target = $(id); target.replaceChildren();
    const entries = id === 'events-list' ? state.log.slice(0, 3) : state.log;
    if (!entries.length) { const p = document.createElement('p'); p.className = 'camera-footnote'; p.textContent = 'No activity recorded yet.'; target.append(p); continue; }
    for (const event of entries) {
      const row = document.createElement('div'); row.className = 'event';
      const icon = document.createElement('span'); icon.className = 'event-symbol'; icon.textContent = event.symbol;
      const content = document.createElement('div');
      const heading = document.createElement('strong'); heading.textContent = event.title;
      const info = document.createElement('p'); info.textContent = event.detail;
      const time = document.createElement('time'); time.textContent = event.time;
      content.append(heading, info); row.append(icon, content, time); target.append(row);
    }
  }
}
function render() {
  $('battery').textContent = Math.max(0, Math.round(state.battery));
  $('battery-meter').style.width = Math.max(0, state.battery) + '%';
  $('battery-note').textContent = state.battery > 25 ? 'Battery simulation' : 'Low simulated battery';
  $('altitude').textContent = state.altitude;
  $('flight-time').textContent = String(Math.floor(state.seconds / 60)).padStart(2, '0') + ':' + String(state.seconds % 60).padStart(2, '0');
  const labels = { docked: '● DOCKED', flying: '● IN FLIGHT', returning: '● RETURNING', landed: '● LANDED' };
  $('status-chip').textContent = labels[state.mode];
  $('feed-mode').textContent = state.mode.toUpperCase();
  $('launch').disabled = !['docked', 'landed'].includes(state.mode) || state.battery < 20;
  $('return').disabled = state.mode !== 'flying';
  $('land').disabled = state.mode !== 'flying';
}
$('launch').addEventListener('click', () => {
  if (state.battery < 20) return toast('Insufficient simulated battery (20% required)');
  if (!window.confirm('Start a simulated flight? This does not control a real drone.')) return;
  state.mode = 'flying'; state.altitude = 4;
  addEvent('Simulated launch', 'Demo aircraft entered flight state.', '▲'); render(); toast('Demo flight started');
});
$('return').addEventListener('click', () => {
  if (state.mode !== 'flying') return;
  state.mode = 'returning'; state.altitude = 2;
  addEvent('Return to dock', 'Simulated return maneuver initiated.', '↩'); render(); toast('Simulated return initiated');
  setTimeout(() => { if (state.mode === 'returning') { state.mode = 'docked'; state.altitude = 0; addEvent('Docked', 'Simulated aircraft returned to dock.', '✓'); render(); } }, 2600);
});
$('land').addEventListener('click', () => {
  if (state.mode !== 'flying') return;
  state.mode = 'landed'; state.altitude = 0;
  addEvent('Simulated landing', 'Demo aircraft landed safely.', '↓'); render(); toast('Simulated landing complete');
});
$('simulate-alert').addEventListener('click', () => {
  if (!$('alerts-enabled').checked) return toast('Demo alerts are disabled in settings');
  addEvent('Simulated motion detected', 'Demo event only • North perimeter', '!'); toast('Demo security alert generated');
});
$('clear-log').addEventListener('click', () => { state.log = []; renderEvents(); toast('Simulation activity cleared'); });
for (const button of document.querySelectorAll('[data-tab]')) {
  button.addEventListener('click', () => {
    const tab = button.dataset.tab;
    for (const panel of document.querySelectorAll('.tab-panel')) panel.classList.toggle('hidden', panel.id !== tab);
    for (const nav of document.querySelectorAll('[data-tab]')) nav.classList.toggle('active', nav === button);
    const titles = { dashboard: 'Drone overview', activity: 'Activity log', settings: 'Settings' };
    $('page-title').textContent = titles[tab]; $('crumb').textContent = tab.toUpperCase();
  });
}
setInterval(() => {
  if (state.mode === 'flying') {
    state.seconds += 1; state.battery = Math.max(0, state.battery - 0.05);
    if (state.battery <= 15) { state.mode = 'landed'; state.altitude = 0; addEvent('Auto-land simulation', 'Low battery safety threshold reached in demo.', '!'); toast('Demo auto-landed at 15% battery'); }
  } else if (state.mode === 'docked') state.battery = Math.min(100, state.battery + 0.08);
  render();
}, 1000);
$('year').textContent = String(new Date().getFullYear());
addEvent('System initialized', 'DPro dashboard started in simulation mode.', '✓');
render();
